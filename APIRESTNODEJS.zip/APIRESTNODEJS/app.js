var express = require('express');
var mysql = require('mysql');
var cors =require('cors');

var app = express();
app.use(express.json());
app.use(cors());


var conexion = mysql.createConnection({
    host:'https://ccavieres.laboratoriodiseno.cl/',
    user:'ccavieres_articulosbd',
    password:'crudcaro/',
    database:'ccavieres_articulosbd'
});
//probar conexion
conexion.connect(function(error){
    if(error){
        throw error;
    }else{
        console.log("conexion existosa");
    }
});

app.get('/', function(req,res){
    res.send('Ruta Principal');
});

//mostrar articulos
app.get('/api/articulo', (req,res)=>{
    conexion.query('SELECT * FROM articulo', (error,filas)=>{
        if(error){
            throw error
        }else{
            res.send(filas);
        }
    });
});

//mostrar un articulo
app.get('/api/articulo/:od', (req,res)=>{
    conexion.query('SELECT * FROM articulo WHERE is =?',[req.params.id], (error,fila)=>{
        if(error){
            throw error
        }else{
            res.send(fila);
            //res.send(fila[0].descripcion);
        }
    });
});

//agregar articulo
app.post('/api/articulo',(req,res)=>{
    let data = {producto:req.body.producto, precio:req.body.precio, unidades:req.body.unidades}
    let sql = "INSERT INTO articulo set ?";
    conexion.query(sql, data, function(error, results){
          if(error){
              throw error;
          }else{
              res.send(results);
          }
      });

    });


    //editar articulo
    app.put('/api/articulo/:id',(req, res)=>{
        let id = req.params.id;
        let producto = req.body.producto;
        let precio = req.body.precio;
        let unidades = req.body.unidades;
        let sql ="UPDATE articulo Aet producto =?, precio =?, unidades = ? WHERE id = ?";
        conexion.query(sql,[producto, precio, unidades, id], function(error, results){
            if(error){
                throw error;
            }else{
                res.send(results);
            }
        });
    });

    //eliminar producto
    app.delete('/api/articulo/:id',(req,res)=>{
        conexion.query('DELETE FROM articulo WHERE id =?', [req.params.id], function(error, filas){
            if(error){
                throw error;
            }else{
                res.send(filas);
            }
        });
    });

const puerto = process.env.PUERTO  ||3000;

app.listen(puerto, function(){
    console.log("servidor ok en puerto:"+puerto);
});